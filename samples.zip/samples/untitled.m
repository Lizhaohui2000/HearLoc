% 获取文件夹中的所有 txt 文件
folderPath = 'E:\Academic documents\paper reading\SSL3D\HearLoc\samples\two_walls_2D'; % 替换为你的文件夹路径
files = dir(fullfile(folderPath, '*.txt'));

% 遍历每个文件
for i = 1:length(files)
    % 读取当前文件的路径
    filePath = fullfile(folderPath, files(i).name);
    
    % 读取文件中的浮点数数组
    data = load(filePath);
    
    % 将数据转换为整数
    intData = round(data);
    
    % 保存整数数据到同一个文件或新文件
    writematrix(intData,filePath);
end
